﻿namespace KollektivSystem.Web.Models
{
    public sealed record UserMeDto(Guid Id, string? Name, string? Email);
}
